import os
from PIL import Image, ImageDraw, ImageColor
im = Image.open('1.png')
im.show()